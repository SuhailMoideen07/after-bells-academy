import React from "react";
import { SectionHeader } from "@/components/ui/section-header";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Users, Sparkles, BookOpenCheck } from "lucide-react";

export const Teachers: React.FC = () => {
  return (
    <section id="teachers" className="py-20 lg:py-28 bg-slate-50/60">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <SectionHeader
          badge="Our Educators"
          title="Meet Our Teachers"
          subtitle="Our dedicated teaching team will be introduced here soon as our educator roster is updated."
        />

        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-premium max-w-2xl mx-auto">
          <div className="w-20 h-20 rounded-3xl bg-navy-subtle flex items-center justify-center text-navy-primary mx-auto mb-6 border border-navy-primary/10 shadow-sm">
            <GraduationCap className="w-10 h-10 text-gold-accent" />
          </div>

          <Badge variant="gold" className="mb-4">
            Teaching Team Introduction Coming Soon
          </Badge>

          <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-8">
            At <strong>After Bells Academy</strong>, our educators are passionate subject specialists committed to interactive, concept-based learning. We look forward to introducing our complete teaching faculty here shortly.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-100 text-xs font-semibold text-slate-700">
            <div className="flex items-center justify-center gap-2">
              <Users className="w-4 h-4 text-navy-primary" /> Small Batch & 1-to-1
            </div>
            <div className="flex items-center justify-center gap-2">
              <BookOpenCheck className="w-4 h-4 text-navy-primary" /> Subject Specialists
            </div>
            <div className="flex items-center justify-center gap-2">
              <Sparkles className="w-4 h-4 text-gold-accent" /> Dedicated Mentors
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
